from gtts import gTTS
import os

text="Viktor Frankl, Austrian neurologist and psychiatrist, founder of logotherapy, a psychotherapeutic approach emphasizing the search for meaning in life. Holocaust survivor and author of ''Man's Search for Meaning,'' detailing his experiences in Nazi concentration camps and emphasizing the individual's ultimate freedom to choose their attitude in any circumstance. Frankl's work focuses on helping individuals discover meaningful purpose, and he remains influential in existential psychology and the pursuit of life's meaning."

language="es"

speech = gTTS(text= text, lang= language, slow= False)

speech.save("Viktor Frankl Ingles.mp3")

os.system("start texto.mp3")